package example;

public class NestedLoopExample {

	public static void main(String[] args) {
/*
		for(int i=1;i<5;i++)		//for rows 
		{
			for(int c=1; c<4;c++)		//for cols
			{				
				System.out.print(c);
			}
			System.out.println(); //new line
		}
	*/	//
		for(int i=1;i<5;i++)		//for rows 
		{
			for(int c=5; c>i;c--)		//for cols
			{				
				
				System.out.print("*");
				
				
			}
			System.out.println(); //new line
		}
	}

}
