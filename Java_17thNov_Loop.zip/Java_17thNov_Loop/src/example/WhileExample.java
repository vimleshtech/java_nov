package example;


import java.util.Scanner;

public class WhileExample {

	public static void main(String[] args) {

		int i=0;  //init
		
		while(i<10) //condition from 0 to 9
		{
			System.out.println(i); //0 1 2 ... ..9 
			i++; //increment 
		}
		
		//print in reverse order
		i =10;
		while(i>0) {
			System.out.println(i);
			i--;
		}
		 
		
		//wap to print all odd numbers between 1 to 30
		i =1;
		while(i<30) {
			System.out.println(i);
			i+=2;
		}

		//wap to get sum or all even and odd numbers between 1 to 100
		i =1;
		int se=0,so=0; 
		while(i<=100)
		{
			if(i % 2 ==0 ) {
				se+=i;
			}else
			{
				so+=i;
			}
			i++;
		}
		System.out.println("sum of all even number : "+se);
		System.out.println("sum of all odd numebr :"+so);
		
		
		//wap to print table of given no.
		Scanner sc =new Scanner(System.in);
		System.out.println("enter number to print the table : ");
		int t = sc.nextInt();
		
		i =1;
		while(i<=10) {
			System.out.println(t+"*"+i+"="+i*t);
			i++;
		}
	}

}
