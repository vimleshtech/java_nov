package example;

public class DoWhileExample {

	public static void main(String[] args) {
	
		//do while: do while loop will execute at least once
		//first execute then check the condition 
		
		int i=1;
		do {
			
			System.out.println(i);
			i++;
		}while(i<1);
		

	}

}
