package example;

import java.util.ArrayList;
import java.util.HashMap;

class emp
{
	int id;
	String name;
	
	emp(int id, String name)
	{
		this.id = id;
		this.name =name;
	}
}
public class ArrayListExample {

	public static void main(String[] args) {

			ArrayList al  = new ArrayList();
			al.add(11);
			al.add("raman");
			al.add(true);
			al.add(11);

			System.out.println(al.size());
			
			al.remove(1);
			System.out.println(al.size());
			
			System.out.println(al.get(1));
			
			//iterator
			for (int i=0; i<al.size();i++)
			{
				System.out.println(al.get(i));
			}
			
			
			//
			ArrayList<Integer> aa = new ArrayList();
			aa.add(11);
			aa.add(44);
			//aa.add("sjhhs");
			
			
			//
			ArrayList<emp> e =new ArrayList();
			e.add(new emp(1,"raman"));
			e.add(new emp(2,"djdhhd"));
			
			for(int i=0;i<e.size();i++)
			{
				emp m = (emp) e.get(i);
				
				System.out.println(m.id+"\t"+m.name);
			}
			
			//type casting
			int d=1;
			long l=3;
			
			d =(int) l;
			
			l=d;
			
			
			//
			HashMap m = new HashMap();
			m.put("a", "alpha");
			m.put(1,"one");
			
			System.out.println(m.get("a"));
			
			m.remove("a");
			
			//
			//HashMap<String, Number> mm=new 
	}

}
