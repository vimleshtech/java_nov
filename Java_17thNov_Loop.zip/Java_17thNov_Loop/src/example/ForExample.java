package example;

public class ForExample {

	public static void main(String[] args) {

		for(int i=1;i<10;i++)
		{
			System.out.println(i);
		}
		//print in reverse
		for(int i=10;i>0;i--)
		{
			System.out.println(i);
		}
		
		//print all odd numebrs between 1 to 30
		for(int i=1;i<30;i=i+2)
		{
			System.out.println(i);
		}
		
		

	}

}
