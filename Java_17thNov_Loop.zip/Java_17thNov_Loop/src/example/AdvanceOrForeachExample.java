package example;

import java.net.SocketTimeoutException;

public class AdvanceOrForeachExample {

	public static void main(String[] args) {

		//foreach/advance: works for collection/array 
		//-forward only
		
		int n[] = {111,11,2,2,2,2,23212,333};
		
		//get sum of all numbers 
		int s=0;
		// : read every element one by one
		for(int d: n) //here d is new variable which will hold element of array , and n is array 
		{
				System.out.println(d);
				s+=d;
		}
		
		System.out.println(s);
	}

}
