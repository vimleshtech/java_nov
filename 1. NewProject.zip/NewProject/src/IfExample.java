
public class IfExample {

	public static void main(String[] args) {
		

		//if condition 
		int sales=500;
		double t=0;
		
		if(sales>1000) {
			t= sales*.18;
		}
		
		t = sales+t;
		System.out.println(t);

		//if else
		
		t=0;		
		if(sales>1000) {
			t= sales*.18;
		}
		else
		{
			t= sales*.05;
		}
		
		t = sales+t;
		System.out.println(t);

		
		//if else if ... else if .else / ladder if else 
		int a=44,b=66,c=45;
		
		if(a>b && a>c)
		{
			System.out.println("a is greater");
		}
		else if(b>a && b>c)
		{
			System.out.println("b is greater");
		}
		else
		{
			System.out.println("c is greater");
		}
		
		//nested if else : if inside if
		if(a>b)
		{
				if(a>c)
					System.out.println("a is gt");
				else
					System.out.println("c is gt");
		}	
		else
		{
			if(b>c)
			{
				
				System.out.println("b is gt");
			}
			else
			{
				System.out.println("c is gt");
			}
		}
		
	}

}
