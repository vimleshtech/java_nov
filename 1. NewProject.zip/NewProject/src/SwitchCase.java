
public class SwitchCase {

	public static void main(String[] args) {

		
			int day=1;
			
			switch (day) {
			
			case 1:
				System.out.println("MONDAY");
				break;
			case 2:
				System.out.println("tueday");
				break;
			case 3:
				System.out.println("wednesday");
				break;
			default:
				System.out.println("NO MATCH");
				break;
			}

	}

}
