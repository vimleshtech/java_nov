
public class Rectangle {

	public static void main(String[] args) {

		int l=2;
		int b=3;
		
		int Area=l*b;
		int peri=2*l*b;
		
		System.out.println("Area and perimeter of rectangle is "+Area+" & "+peri);
		
	}

}
