
public class Circle {

	public static void main(String[] args) {

		float r=2 ;
		float Area;
		float Circum;
		Area = 3.14f*r*r;
		Circum = 2*3.14f*r;
		System.out.println("Area of circle & Circumference of radius "+r+" is "+Area+ " & " +Circum);
	}

}
