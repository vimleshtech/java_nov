
public class Cube {

	public static void main(String[] args) 
	{
	
		int l=2;
		int Cube;
		
		Cube=l*l*l;
		
		System.out.println("Cube of " +l +" is " + Cube );
		
	}

}
